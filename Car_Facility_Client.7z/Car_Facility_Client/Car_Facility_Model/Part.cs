﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Car_Facility_Model
{
    [Serializable, XmlRoot("part")]
    class Part
    {
        [XmlElement("partId")]
        public int PartId { get; set; }
        [XmlElement("name")]
        public string Name { get; set; }
        [XmlElement("type")]
        public string Type { get; set; }
        [XmlElement("weight")]
        public double Weight { get; set; }
        [XmlElement("car")]
        public Car Car { get; set; }
        [XmlElement("pallet")]
        public Pallet Pallet { get; set; }
        [XmlElement("product")]
        public Product Product { get; set; }

        public Part() { }
    }
}
