﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Car_Facility_Model
{
    [Serializable, XmlRoot("product")]
    class Product
    {
        [XmlElement("productId")]
        public int ProductId { get; set; }
        [XmlElement("name")]
        public string Name { get; set; }
        [XmlElement("type")]
        public string Type { get; set; }
    }
}
