﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Car_Facility_Model
{
    [Serializable, XmlRoot("pallet")]
    class Pallet
    {
        [XmlElement("palletId")]
        public int PalletId { get; set; }
        [XmlElement("partType")]
        public string PartType { get; set; }
        [XmlElement("maxWeight")]
        public double MaxWeight { get; set; }
        [XmlElement("isFinished")]
        public bool IsFinished { get; set; }

        public Pallet() { }
    }
}
