﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Car_Facility_Model
{
    [Serializable, XmlRoot("car")]
    public class Car
    {
        [XmlElement("carId")]
        public int CarId { get; set; }
        [XmlElement("year")]
        public int Year { get; set; }
        [XmlElement("chassisNumber")]
        public string ChassisNumber { get; set; }
        [XmlElement("model")]
        public string Model { get; set; }
        [XmlElement("manufacturer")]
        public string Manufacturer { get; set; }
        [XmlElement("weight")]
        public double Weight { get; set; }
        [XmlElement("isReady")]
        public bool IsReady { get; set; }
        [XmlElement("isFinished")]
        public bool IsFinished { get; set; }

        public Car() { }
    }
}
