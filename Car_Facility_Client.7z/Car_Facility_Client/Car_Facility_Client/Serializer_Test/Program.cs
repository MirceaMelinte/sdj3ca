﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Car_Facility_Model;
using Serializer;

namespace Serializer_Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Car c = new Car
            {
                CarId = 1
            };

            var ser = new Serializer.Serializer();

            string s = ser.CreateXMLString(c);

            var client = new ICarService.CarServicePortTypeClient();



            Console.WriteLine(client.traceCar(s));

            Console.ReadKey();
        }
    }
}
